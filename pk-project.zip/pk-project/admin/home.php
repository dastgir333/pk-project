<?php
require("includes/header.php");
require("includes/nav.php");
?>

		body part
<?php
require("includes/footer.php");

?>	