<?php
require("lib/session_security.php");

require("db.php");

$sql = "select * from `category`";

$rs = mysqli_query($con, $sql) or die(mysqli_error($con));

$result = array();
while($row = mysqli_fetch_object($rs)){
    array_push($result, $row);
}
 
echo json_encode($result);