<?php
require("lib/session_security.php");

require("db.php");
require("includes/header.php");
require("includes/nav.php");
$where = "";
$srch = "";
if(isset($_REQUEST['srch'])){
	extract($_REQUEST);
	$where = "where `name` like '%$srch%'";
}
// get the total record
$sql = "select * from `category` $where";
$res = mysqli_query($con, $sql) or die(mysqli_error($con));
$total = mysqli_num_rows($res);
$start = 0;
$limit = 3;
$page = ceil($total / $limit);

if(isset($_REQUEST['p'])){
	$start = ($_REQUEST['p']-1) * $limit;
}


print "
<form action='category.php' method='post'>
Search: <input type='text' name='srch'>
<input type='submit' value='Search'>
<a href='category.php'>show all</a>
</form>
";

$sql = "select * from `category` $where LIMIT $start,$limit";
print "<div style='background:blue;color:white;width:80%'>$sql</div>";
$res = mysqli_query($con, $sql) or die(mysqli_error($con));
if(isset($_REQUEST['msg'])){
	print"<div style='color:#f00;'> $_REQUEST[msg]</div>";
}
echo "<a href='add-cat.php'>Add  More Category...</a>";

print "<table width='400' border='1' style='border-collapse:collapse;'>
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>isActive</th>
			<th>Option</th>
		</tr>";
while($row = mysqli_fetch_assoc($res)){
	print "<tr>
			<td>$row[id]</td>
			<td>$row[name]</td>
			<td>$row[is_active]</td>
			<td>
			<a href='#' onclick='confirmDel(\"del-cat.php?id=$row[id]\")'><img src='img/del.png' height='30' width='30'></a>
			<a href='edit-cat.php?id=$row[id]'><img src='img/edit.png' height='30' width='30'></a>
			</td>
		</tr>";
}
print "</table>";

print "<div>";
for($i=1;$i<=$page;$i++){
	echo "<a href='category.php?p=$i&srch=$srch'>$i</a> | ";
}
print "</div>";


?>
<script type="text/javascript">
function confirmDel(x){
	var r = confirm("Are you sure to delete?");
	if (r == true) {
		window.location = x;
	} 
	else {
		return false;
	}

}
</script>

<?php
require("includes/footer.php");

?>