	<tr>
		<td width="20%" valign="top">
			<ul style="font-size:20px;">
				<li><a href="category.php">Manage Category</a></li>
				<li><a href="product.php">Manage Product</a></li>
				<li><a href="orders.php">Manage Orders</a></li>
			</ul>
		</td>
		<td width="80%" valign="top" align="center">