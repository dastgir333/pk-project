<?php
require("lib/session_security.php");

require("db.php");
$id = $_REQUEST['id'];
$sql = "select * from `product` where `id` = '$id'";
$res = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($res);

// get all category
$sql_cat = "select * from `category`";
$res_cat = mysqli_query($con, $sql_cat);
?>

<form action="editing-pro.php" method="post" enctype="multipart/form-data">

Select Category:
<select name="cat_id">
<?php
while($row_cat = mysqli_fetch_assoc($res_cat)){
	$selected = ($row['cat_id'] == $row_cat['id']) ? "selected" : "";
	
	echo "<option value='$row_cat[id]' $selected>$row_cat[name]</option>";
}
?>
</select>
<input type="hidden" name="pid" value="<?php echo $row['id'] ?>" >
<br>

Name: <input type="text" name="nm" value="<?php 
        echo $row['name']?>"><br>
Price: <input type="text" name="prc" value="<?php 
        echo $row['price']?>"><br>

     Description: <textarea name="dsc"><?php echo $row['description'] ?></textarea>
     <br>
Image: <input type="file" name="im">
<input type="hidden" name="oldIm" value="<?php echo $row['image'] ?>">
	<br>
     
isActive: <input type="radio" name="isActive" value="y" <?php echo ($row['is_active'] == "y")? "checked='checked'":"";?> > Yes 
 <input type="radio" name="isActive" value="n" <?php echo ($row['is_active'] == "n")? "checked='checked'":"";?>> 
 No
 <input type="submit" value="Update"> 
</form>