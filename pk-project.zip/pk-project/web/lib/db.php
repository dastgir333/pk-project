<?php
$con = mysqli_connect("localhost","root","","mobile_store");
if(!$con){

	die("connection error");
}

